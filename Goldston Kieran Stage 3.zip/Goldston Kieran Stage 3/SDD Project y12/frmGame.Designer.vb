﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGame
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmGame))
        Me.lstGameStats = New System.Windows.Forms.ListBox()
        Me.BtnHighScores = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.lblMatchStats = New System.Windows.Forms.Label()
        Me.btnWin = New System.Windows.Forms.Button()
        Me.picBox88 = New System.Windows.Forms.PictureBox()
        Me.picBox87 = New System.Windows.Forms.PictureBox()
        Me.picBox86 = New System.Windows.Forms.PictureBox()
        Me.picBox85 = New System.Windows.Forms.PictureBox()
        Me.picBox84 = New System.Windows.Forms.PictureBox()
        Me.picBox83 = New System.Windows.Forms.PictureBox()
        Me.picBox82 = New System.Windows.Forms.PictureBox()
        Me.picBox81 = New System.Windows.Forms.PictureBox()
        Me.picBox78 = New System.Windows.Forms.PictureBox()
        Me.picBox77 = New System.Windows.Forms.PictureBox()
        Me.picBox76 = New System.Windows.Forms.PictureBox()
        Me.picBox75 = New System.Windows.Forms.PictureBox()
        Me.picBox74 = New System.Windows.Forms.PictureBox()
        Me.picBox73 = New System.Windows.Forms.PictureBox()
        Me.picBox72 = New System.Windows.Forms.PictureBox()
        Me.picBox71 = New System.Windows.Forms.PictureBox()
        Me.picBox68 = New System.Windows.Forms.PictureBox()
        Me.picBox67 = New System.Windows.Forms.PictureBox()
        Me.picBox66 = New System.Windows.Forms.PictureBox()
        Me.picBox65 = New System.Windows.Forms.PictureBox()
        Me.picBox64 = New System.Windows.Forms.PictureBox()
        Me.picBox63 = New System.Windows.Forms.PictureBox()
        Me.picBox62 = New System.Windows.Forms.PictureBox()
        Me.picBox61 = New System.Windows.Forms.PictureBox()
        Me.picBox58 = New System.Windows.Forms.PictureBox()
        Me.picBox57 = New System.Windows.Forms.PictureBox()
        Me.picBox56 = New System.Windows.Forms.PictureBox()
        Me.picBox55 = New System.Windows.Forms.PictureBox()
        Me.picBox54 = New System.Windows.Forms.PictureBox()
        Me.picBox53 = New System.Windows.Forms.PictureBox()
        Me.picBox52 = New System.Windows.Forms.PictureBox()
        Me.picBox51 = New System.Windows.Forms.PictureBox()
        Me.picBox48 = New System.Windows.Forms.PictureBox()
        Me.picBox47 = New System.Windows.Forms.PictureBox()
        Me.picBox46 = New System.Windows.Forms.PictureBox()
        Me.picBox45 = New System.Windows.Forms.PictureBox()
        Me.picBox44 = New System.Windows.Forms.PictureBox()
        Me.picBox43 = New System.Windows.Forms.PictureBox()
        Me.picBox42 = New System.Windows.Forms.PictureBox()
        Me.picBox41 = New System.Windows.Forms.PictureBox()
        Me.picBox38 = New System.Windows.Forms.PictureBox()
        Me.picBox37 = New System.Windows.Forms.PictureBox()
        Me.picBox36 = New System.Windows.Forms.PictureBox()
        Me.picBox35 = New System.Windows.Forms.PictureBox()
        Me.picBox34 = New System.Windows.Forms.PictureBox()
        Me.picBox33 = New System.Windows.Forms.PictureBox()
        Me.picBox32 = New System.Windows.Forms.PictureBox()
        Me.picBox31 = New System.Windows.Forms.PictureBox()
        Me.picBox28 = New System.Windows.Forms.PictureBox()
        Me.picBox27 = New System.Windows.Forms.PictureBox()
        Me.picBox26 = New System.Windows.Forms.PictureBox()
        Me.picBox25 = New System.Windows.Forms.PictureBox()
        Me.picBox24 = New System.Windows.Forms.PictureBox()
        Me.picBox23 = New System.Windows.Forms.PictureBox()
        Me.picBox22 = New System.Windows.Forms.PictureBox()
        Me.picBox21 = New System.Windows.Forms.PictureBox()
        Me.picBox18 = New System.Windows.Forms.PictureBox()
        Me.picBox17 = New System.Windows.Forms.PictureBox()
        Me.picBox16 = New System.Windows.Forms.PictureBox()
        Me.picBox15 = New System.Windows.Forms.PictureBox()
        Me.picBox14 = New System.Windows.Forms.PictureBox()
        Me.picBox13 = New System.Windows.Forms.PictureBox()
        Me.picBox12 = New System.Windows.Forms.PictureBox()
        Me.picBox11 = New System.Windows.Forms.PictureBox()
        Me.btnHelp = New System.Windows.Forms.Button()
        CType(Me.picBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox81, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lstGameStats
        '
        Me.lstGameStats.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstGameStats.FormattingEnabled = True
        Me.lstGameStats.ItemHeight = 16
        Me.lstGameStats.Location = New System.Drawing.Point(447, 168)
        Me.lstGameStats.Name = "lstGameStats"
        Me.lstGameStats.Size = New System.Drawing.Size(334, 244)
        Me.lstGameStats.TabIndex = 0
        '
        'BtnHighScores
        '
        Me.BtnHighScores.BackColor = System.Drawing.Color.DodgerBlue
        Me.BtnHighScores.BackgroundImage = Global.SDD_Project_y12.My.Resources.Resources.istockphoto_1145602814_612x612
        Me.BtnHighScores.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHighScores.ForeColor = System.Drawing.Color.White
        Me.BtnHighScores.Location = New System.Drawing.Point(681, 45)
        Me.BtnHighScores.Name = "BtnHighScores"
        Me.BtnHighScores.Size = New System.Drawing.Size(113, 50)
        Me.BtnHighScores.TabIndex = 164
        Me.BtnHighScores.Text = "High Scores"
        Me.BtnHighScores.UseVisualStyleBackColor = False
        '
        'btnHome
        '
        Me.btnHome.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnHome.BackgroundImage = Global.SDD_Project_y12.My.Resources.Resources.istockphoto_1145602814_612x612
        Me.btnHome.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHome.ForeColor = System.Drawing.Color.White
        Me.btnHome.Location = New System.Drawing.Point(562, 45)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(113, 50)
        Me.btnHome.TabIndex = 165
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = False
        '
        'lblMatchStats
        '
        Me.lblMatchStats.AutoSize = True
        Me.lblMatchStats.BackColor = System.Drawing.Color.Transparent
        Me.lblMatchStats.Font = New System.Drawing.Font("Stencil", 24.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMatchStats.Location = New System.Drawing.Point(451, 126)
        Me.lblMatchStats.Name = "lblMatchStats"
        Me.lblMatchStats.Size = New System.Drawing.Size(330, 39)
        Me.lblMatchStats.TabIndex = 166
        Me.lblMatchStats.Text = "Match Statistics"
        '
        'btnWin
        '
        Me.btnWin.BackColor = System.Drawing.Color.Red
        Me.btnWin.Enabled = False
        Me.btnWin.ForeColor = System.Drawing.Color.White
        Me.btnWin.Location = New System.Drawing.Point(458, 15)
        Me.btnWin.Name = "btnWin"
        Me.btnWin.Size = New System.Drawing.Size(37, 23)
        Me.btnWin.TabIndex = 167
        Me.btnWin.Text = "win"
        Me.btnWin.UseVisualStyleBackColor = False
        Me.btnWin.Visible = False
        '
        'picBox88
        '
        Me.picBox88.Location = New System.Drawing.Point(366, 365)
        Me.picBox88.Name = "picBox88"
        Me.picBox88.Size = New System.Drawing.Size(50, 50)
        Me.picBox88.TabIndex = 232
        Me.picBox88.TabStop = False
        '
        'picBox87
        '
        Me.picBox87.Location = New System.Drawing.Point(316, 365)
        Me.picBox87.Name = "picBox87"
        Me.picBox87.Size = New System.Drawing.Size(50, 50)
        Me.picBox87.TabIndex = 231
        Me.picBox87.TabStop = False
        '
        'picBox86
        '
        Me.picBox86.Location = New System.Drawing.Point(266, 365)
        Me.picBox86.Name = "picBox86"
        Me.picBox86.Size = New System.Drawing.Size(50, 50)
        Me.picBox86.TabIndex = 230
        Me.picBox86.TabStop = False
        '
        'picBox85
        '
        Me.picBox85.Location = New System.Drawing.Point(216, 365)
        Me.picBox85.Name = "picBox85"
        Me.picBox85.Size = New System.Drawing.Size(50, 50)
        Me.picBox85.TabIndex = 229
        Me.picBox85.TabStop = False
        '
        'picBox84
        '
        Me.picBox84.Location = New System.Drawing.Point(166, 365)
        Me.picBox84.Name = "picBox84"
        Me.picBox84.Size = New System.Drawing.Size(50, 50)
        Me.picBox84.TabIndex = 228
        Me.picBox84.TabStop = False
        '
        'picBox83
        '
        Me.picBox83.Location = New System.Drawing.Point(116, 365)
        Me.picBox83.Name = "picBox83"
        Me.picBox83.Size = New System.Drawing.Size(50, 50)
        Me.picBox83.TabIndex = 227
        Me.picBox83.TabStop = False
        '
        'picBox82
        '
        Me.picBox82.Location = New System.Drawing.Point(66, 365)
        Me.picBox82.Name = "picBox82"
        Me.picBox82.Size = New System.Drawing.Size(50, 50)
        Me.picBox82.TabIndex = 226
        Me.picBox82.TabStop = False
        '
        'picBox81
        '
        Me.picBox81.Location = New System.Drawing.Point(16, 365)
        Me.picBox81.Name = "picBox81"
        Me.picBox81.Size = New System.Drawing.Size(50, 50)
        Me.picBox81.TabIndex = 225
        Me.picBox81.TabStop = False
        '
        'picBox78
        '
        Me.picBox78.Location = New System.Drawing.Point(366, 315)
        Me.picBox78.Name = "picBox78"
        Me.picBox78.Size = New System.Drawing.Size(50, 50)
        Me.picBox78.TabIndex = 224
        Me.picBox78.TabStop = False
        '
        'picBox77
        '
        Me.picBox77.Location = New System.Drawing.Point(316, 315)
        Me.picBox77.Name = "picBox77"
        Me.picBox77.Size = New System.Drawing.Size(50, 50)
        Me.picBox77.TabIndex = 223
        Me.picBox77.TabStop = False
        '
        'picBox76
        '
        Me.picBox76.Location = New System.Drawing.Point(266, 315)
        Me.picBox76.Name = "picBox76"
        Me.picBox76.Size = New System.Drawing.Size(50, 50)
        Me.picBox76.TabIndex = 222
        Me.picBox76.TabStop = False
        '
        'picBox75
        '
        Me.picBox75.Location = New System.Drawing.Point(216, 315)
        Me.picBox75.Name = "picBox75"
        Me.picBox75.Size = New System.Drawing.Size(50, 50)
        Me.picBox75.TabIndex = 221
        Me.picBox75.TabStop = False
        '
        'picBox74
        '
        Me.picBox74.Location = New System.Drawing.Point(166, 315)
        Me.picBox74.Name = "picBox74"
        Me.picBox74.Size = New System.Drawing.Size(50, 50)
        Me.picBox74.TabIndex = 220
        Me.picBox74.TabStop = False
        '
        'picBox73
        '
        Me.picBox73.Location = New System.Drawing.Point(116, 315)
        Me.picBox73.Name = "picBox73"
        Me.picBox73.Size = New System.Drawing.Size(50, 50)
        Me.picBox73.TabIndex = 219
        Me.picBox73.TabStop = False
        '
        'picBox72
        '
        Me.picBox72.Location = New System.Drawing.Point(66, 315)
        Me.picBox72.Name = "picBox72"
        Me.picBox72.Size = New System.Drawing.Size(50, 50)
        Me.picBox72.TabIndex = 218
        Me.picBox72.TabStop = False
        '
        'picBox71
        '
        Me.picBox71.Location = New System.Drawing.Point(16, 315)
        Me.picBox71.Name = "picBox71"
        Me.picBox71.Size = New System.Drawing.Size(50, 50)
        Me.picBox71.TabIndex = 217
        Me.picBox71.TabStop = False
        '
        'picBox68
        '
        Me.picBox68.Location = New System.Drawing.Point(366, 265)
        Me.picBox68.Name = "picBox68"
        Me.picBox68.Size = New System.Drawing.Size(50, 50)
        Me.picBox68.TabIndex = 216
        Me.picBox68.TabStop = False
        '
        'picBox67
        '
        Me.picBox67.Location = New System.Drawing.Point(316, 265)
        Me.picBox67.Name = "picBox67"
        Me.picBox67.Size = New System.Drawing.Size(50, 50)
        Me.picBox67.TabIndex = 215
        Me.picBox67.TabStop = False
        '
        'picBox66
        '
        Me.picBox66.Location = New System.Drawing.Point(266, 265)
        Me.picBox66.Name = "picBox66"
        Me.picBox66.Size = New System.Drawing.Size(50, 50)
        Me.picBox66.TabIndex = 214
        Me.picBox66.TabStop = False
        '
        'picBox65
        '
        Me.picBox65.Location = New System.Drawing.Point(216, 265)
        Me.picBox65.Name = "picBox65"
        Me.picBox65.Size = New System.Drawing.Size(50, 50)
        Me.picBox65.TabIndex = 213
        Me.picBox65.TabStop = False
        '
        'picBox64
        '
        Me.picBox64.Location = New System.Drawing.Point(166, 265)
        Me.picBox64.Name = "picBox64"
        Me.picBox64.Size = New System.Drawing.Size(50, 50)
        Me.picBox64.TabIndex = 212
        Me.picBox64.TabStop = False
        '
        'picBox63
        '
        Me.picBox63.Location = New System.Drawing.Point(116, 265)
        Me.picBox63.Name = "picBox63"
        Me.picBox63.Size = New System.Drawing.Size(50, 50)
        Me.picBox63.TabIndex = 211
        Me.picBox63.TabStop = False
        '
        'picBox62
        '
        Me.picBox62.Location = New System.Drawing.Point(66, 265)
        Me.picBox62.Name = "picBox62"
        Me.picBox62.Size = New System.Drawing.Size(50, 50)
        Me.picBox62.TabIndex = 210
        Me.picBox62.TabStop = False
        '
        'picBox61
        '
        Me.picBox61.Location = New System.Drawing.Point(16, 265)
        Me.picBox61.Name = "picBox61"
        Me.picBox61.Size = New System.Drawing.Size(50, 50)
        Me.picBox61.TabIndex = 209
        Me.picBox61.TabStop = False
        '
        'picBox58
        '
        Me.picBox58.Location = New System.Drawing.Point(366, 215)
        Me.picBox58.Name = "picBox58"
        Me.picBox58.Size = New System.Drawing.Size(50, 50)
        Me.picBox58.TabIndex = 208
        Me.picBox58.TabStop = False
        '
        'picBox57
        '
        Me.picBox57.Location = New System.Drawing.Point(316, 215)
        Me.picBox57.Name = "picBox57"
        Me.picBox57.Size = New System.Drawing.Size(50, 50)
        Me.picBox57.TabIndex = 207
        Me.picBox57.TabStop = False
        '
        'picBox56
        '
        Me.picBox56.Location = New System.Drawing.Point(266, 215)
        Me.picBox56.Name = "picBox56"
        Me.picBox56.Size = New System.Drawing.Size(50, 50)
        Me.picBox56.TabIndex = 206
        Me.picBox56.TabStop = False
        '
        'picBox55
        '
        Me.picBox55.Location = New System.Drawing.Point(216, 215)
        Me.picBox55.Name = "picBox55"
        Me.picBox55.Size = New System.Drawing.Size(50, 50)
        Me.picBox55.TabIndex = 205
        Me.picBox55.TabStop = False
        '
        'picBox54
        '
        Me.picBox54.Location = New System.Drawing.Point(166, 215)
        Me.picBox54.Name = "picBox54"
        Me.picBox54.Size = New System.Drawing.Size(50, 50)
        Me.picBox54.TabIndex = 204
        Me.picBox54.TabStop = False
        '
        'picBox53
        '
        Me.picBox53.Location = New System.Drawing.Point(116, 215)
        Me.picBox53.Name = "picBox53"
        Me.picBox53.Size = New System.Drawing.Size(50, 50)
        Me.picBox53.TabIndex = 203
        Me.picBox53.TabStop = False
        '
        'picBox52
        '
        Me.picBox52.Location = New System.Drawing.Point(66, 215)
        Me.picBox52.Name = "picBox52"
        Me.picBox52.Size = New System.Drawing.Size(50, 50)
        Me.picBox52.TabIndex = 202
        Me.picBox52.TabStop = False
        '
        'picBox51
        '
        Me.picBox51.Location = New System.Drawing.Point(16, 215)
        Me.picBox51.Name = "picBox51"
        Me.picBox51.Size = New System.Drawing.Size(50, 50)
        Me.picBox51.TabIndex = 201
        Me.picBox51.TabStop = False
        '
        'picBox48
        '
        Me.picBox48.Location = New System.Drawing.Point(366, 165)
        Me.picBox48.Name = "picBox48"
        Me.picBox48.Size = New System.Drawing.Size(50, 50)
        Me.picBox48.TabIndex = 200
        Me.picBox48.TabStop = False
        '
        'picBox47
        '
        Me.picBox47.Location = New System.Drawing.Point(316, 165)
        Me.picBox47.Name = "picBox47"
        Me.picBox47.Size = New System.Drawing.Size(50, 50)
        Me.picBox47.TabIndex = 199
        Me.picBox47.TabStop = False
        '
        'picBox46
        '
        Me.picBox46.Location = New System.Drawing.Point(266, 165)
        Me.picBox46.Name = "picBox46"
        Me.picBox46.Size = New System.Drawing.Size(50, 50)
        Me.picBox46.TabIndex = 198
        Me.picBox46.TabStop = False
        '
        'picBox45
        '
        Me.picBox45.Location = New System.Drawing.Point(216, 165)
        Me.picBox45.Name = "picBox45"
        Me.picBox45.Size = New System.Drawing.Size(50, 50)
        Me.picBox45.TabIndex = 197
        Me.picBox45.TabStop = False
        '
        'picBox44
        '
        Me.picBox44.Location = New System.Drawing.Point(166, 165)
        Me.picBox44.Name = "picBox44"
        Me.picBox44.Size = New System.Drawing.Size(50, 50)
        Me.picBox44.TabIndex = 196
        Me.picBox44.TabStop = False
        '
        'picBox43
        '
        Me.picBox43.Location = New System.Drawing.Point(116, 165)
        Me.picBox43.Name = "picBox43"
        Me.picBox43.Size = New System.Drawing.Size(50, 50)
        Me.picBox43.TabIndex = 195
        Me.picBox43.TabStop = False
        '
        'picBox42
        '
        Me.picBox42.Location = New System.Drawing.Point(66, 165)
        Me.picBox42.Name = "picBox42"
        Me.picBox42.Size = New System.Drawing.Size(50, 50)
        Me.picBox42.TabIndex = 194
        Me.picBox42.TabStop = False
        '
        'picBox41
        '
        Me.picBox41.Location = New System.Drawing.Point(16, 165)
        Me.picBox41.Name = "picBox41"
        Me.picBox41.Size = New System.Drawing.Size(50, 50)
        Me.picBox41.TabIndex = 193
        Me.picBox41.TabStop = False
        '
        'picBox38
        '
        Me.picBox38.Location = New System.Drawing.Point(366, 115)
        Me.picBox38.Name = "picBox38"
        Me.picBox38.Size = New System.Drawing.Size(50, 50)
        Me.picBox38.TabIndex = 192
        Me.picBox38.TabStop = False
        '
        'picBox37
        '
        Me.picBox37.Location = New System.Drawing.Point(316, 115)
        Me.picBox37.Name = "picBox37"
        Me.picBox37.Size = New System.Drawing.Size(50, 50)
        Me.picBox37.TabIndex = 191
        Me.picBox37.TabStop = False
        '
        'picBox36
        '
        Me.picBox36.Location = New System.Drawing.Point(266, 115)
        Me.picBox36.Name = "picBox36"
        Me.picBox36.Size = New System.Drawing.Size(50, 50)
        Me.picBox36.TabIndex = 190
        Me.picBox36.TabStop = False
        '
        'picBox35
        '
        Me.picBox35.Location = New System.Drawing.Point(216, 115)
        Me.picBox35.Name = "picBox35"
        Me.picBox35.Size = New System.Drawing.Size(50, 50)
        Me.picBox35.TabIndex = 189
        Me.picBox35.TabStop = False
        '
        'picBox34
        '
        Me.picBox34.Location = New System.Drawing.Point(166, 115)
        Me.picBox34.Name = "picBox34"
        Me.picBox34.Size = New System.Drawing.Size(50, 50)
        Me.picBox34.TabIndex = 188
        Me.picBox34.TabStop = False
        '
        'picBox33
        '
        Me.picBox33.Location = New System.Drawing.Point(116, 115)
        Me.picBox33.Name = "picBox33"
        Me.picBox33.Size = New System.Drawing.Size(50, 50)
        Me.picBox33.TabIndex = 187
        Me.picBox33.TabStop = False
        '
        'picBox32
        '
        Me.picBox32.Location = New System.Drawing.Point(66, 115)
        Me.picBox32.Name = "picBox32"
        Me.picBox32.Size = New System.Drawing.Size(50, 50)
        Me.picBox32.TabIndex = 186
        Me.picBox32.TabStop = False
        '
        'picBox31
        '
        Me.picBox31.Location = New System.Drawing.Point(16, 115)
        Me.picBox31.Name = "picBox31"
        Me.picBox31.Size = New System.Drawing.Size(50, 50)
        Me.picBox31.TabIndex = 185
        Me.picBox31.TabStop = False
        '
        'picBox28
        '
        Me.picBox28.Location = New System.Drawing.Point(366, 65)
        Me.picBox28.Name = "picBox28"
        Me.picBox28.Size = New System.Drawing.Size(50, 50)
        Me.picBox28.TabIndex = 184
        Me.picBox28.TabStop = False
        '
        'picBox27
        '
        Me.picBox27.Location = New System.Drawing.Point(316, 65)
        Me.picBox27.Name = "picBox27"
        Me.picBox27.Size = New System.Drawing.Size(50, 50)
        Me.picBox27.TabIndex = 183
        Me.picBox27.TabStop = False
        '
        'picBox26
        '
        Me.picBox26.Location = New System.Drawing.Point(266, 65)
        Me.picBox26.Name = "picBox26"
        Me.picBox26.Size = New System.Drawing.Size(50, 50)
        Me.picBox26.TabIndex = 182
        Me.picBox26.TabStop = False
        '
        'picBox25
        '
        Me.picBox25.Location = New System.Drawing.Point(216, 65)
        Me.picBox25.Name = "picBox25"
        Me.picBox25.Size = New System.Drawing.Size(50, 50)
        Me.picBox25.TabIndex = 181
        Me.picBox25.TabStop = False
        '
        'picBox24
        '
        Me.picBox24.Location = New System.Drawing.Point(166, 65)
        Me.picBox24.Name = "picBox24"
        Me.picBox24.Size = New System.Drawing.Size(50, 50)
        Me.picBox24.TabIndex = 180
        Me.picBox24.TabStop = False
        '
        'picBox23
        '
        Me.picBox23.Location = New System.Drawing.Point(116, 65)
        Me.picBox23.Name = "picBox23"
        Me.picBox23.Size = New System.Drawing.Size(50, 50)
        Me.picBox23.TabIndex = 179
        Me.picBox23.TabStop = False
        '
        'picBox22
        '
        Me.picBox22.Location = New System.Drawing.Point(66, 65)
        Me.picBox22.Name = "picBox22"
        Me.picBox22.Size = New System.Drawing.Size(50, 50)
        Me.picBox22.TabIndex = 178
        Me.picBox22.TabStop = False
        '
        'picBox21
        '
        Me.picBox21.Location = New System.Drawing.Point(16, 65)
        Me.picBox21.Name = "picBox21"
        Me.picBox21.Size = New System.Drawing.Size(50, 50)
        Me.picBox21.TabIndex = 177
        Me.picBox21.TabStop = False
        '
        'picBox18
        '
        Me.picBox18.Location = New System.Drawing.Point(366, 15)
        Me.picBox18.Name = "picBox18"
        Me.picBox18.Size = New System.Drawing.Size(50, 50)
        Me.picBox18.TabIndex = 176
        Me.picBox18.TabStop = False
        '
        'picBox17
        '
        Me.picBox17.Location = New System.Drawing.Point(316, 15)
        Me.picBox17.Name = "picBox17"
        Me.picBox17.Size = New System.Drawing.Size(50, 50)
        Me.picBox17.TabIndex = 175
        Me.picBox17.TabStop = False
        '
        'picBox16
        '
        Me.picBox16.Location = New System.Drawing.Point(266, 15)
        Me.picBox16.Name = "picBox16"
        Me.picBox16.Size = New System.Drawing.Size(50, 50)
        Me.picBox16.TabIndex = 174
        Me.picBox16.TabStop = False
        '
        'picBox15
        '
        Me.picBox15.Location = New System.Drawing.Point(216, 15)
        Me.picBox15.Name = "picBox15"
        Me.picBox15.Size = New System.Drawing.Size(50, 50)
        Me.picBox15.TabIndex = 173
        Me.picBox15.TabStop = False
        '
        'picBox14
        '
        Me.picBox14.Location = New System.Drawing.Point(166, 15)
        Me.picBox14.Name = "picBox14"
        Me.picBox14.Size = New System.Drawing.Size(50, 50)
        Me.picBox14.TabIndex = 172
        Me.picBox14.TabStop = False
        '
        'picBox13
        '
        Me.picBox13.Location = New System.Drawing.Point(116, 15)
        Me.picBox13.Name = "picBox13"
        Me.picBox13.Size = New System.Drawing.Size(50, 50)
        Me.picBox13.TabIndex = 171
        Me.picBox13.TabStop = False
        '
        'picBox12
        '
        Me.picBox12.Location = New System.Drawing.Point(66, 15)
        Me.picBox12.Name = "picBox12"
        Me.picBox12.Size = New System.Drawing.Size(50, 50)
        Me.picBox12.TabIndex = 170
        Me.picBox12.TabStop = False
        '
        'picBox11
        '
        Me.picBox11.Location = New System.Drawing.Point(16, 15)
        Me.picBox11.Name = "picBox11"
        Me.picBox11.Size = New System.Drawing.Size(50, 50)
        Me.picBox11.TabIndex = 169
        Me.picBox11.TabStop = False
        '
        'btnHelp
        '
        Me.btnHelp.BackColor = System.Drawing.Color.SlateGray
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.ForeColor = System.Drawing.Color.White
        Me.btnHelp.Location = New System.Drawing.Point(716, 5)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(78, 33)
        Me.btnHelp.TabIndex = 233
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = False
        '
        'frmGame
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.SDD_Project_y12.My.Resources.Resources.Brown_wooden_parquet_texture
        Me.ClientSize = New System.Drawing.Size(800, 425)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.picBox88)
        Me.Controls.Add(Me.picBox87)
        Me.Controls.Add(Me.picBox86)
        Me.Controls.Add(Me.picBox85)
        Me.Controls.Add(Me.picBox84)
        Me.Controls.Add(Me.picBox83)
        Me.Controls.Add(Me.picBox82)
        Me.Controls.Add(Me.picBox81)
        Me.Controls.Add(Me.picBox78)
        Me.Controls.Add(Me.picBox77)
        Me.Controls.Add(Me.picBox76)
        Me.Controls.Add(Me.picBox75)
        Me.Controls.Add(Me.picBox74)
        Me.Controls.Add(Me.picBox73)
        Me.Controls.Add(Me.picBox72)
        Me.Controls.Add(Me.picBox71)
        Me.Controls.Add(Me.picBox68)
        Me.Controls.Add(Me.picBox67)
        Me.Controls.Add(Me.picBox66)
        Me.Controls.Add(Me.picBox65)
        Me.Controls.Add(Me.picBox64)
        Me.Controls.Add(Me.picBox63)
        Me.Controls.Add(Me.picBox62)
        Me.Controls.Add(Me.picBox61)
        Me.Controls.Add(Me.picBox58)
        Me.Controls.Add(Me.picBox57)
        Me.Controls.Add(Me.picBox56)
        Me.Controls.Add(Me.picBox55)
        Me.Controls.Add(Me.picBox54)
        Me.Controls.Add(Me.picBox53)
        Me.Controls.Add(Me.picBox52)
        Me.Controls.Add(Me.picBox51)
        Me.Controls.Add(Me.picBox48)
        Me.Controls.Add(Me.picBox47)
        Me.Controls.Add(Me.picBox46)
        Me.Controls.Add(Me.picBox45)
        Me.Controls.Add(Me.picBox44)
        Me.Controls.Add(Me.picBox43)
        Me.Controls.Add(Me.picBox42)
        Me.Controls.Add(Me.picBox41)
        Me.Controls.Add(Me.picBox38)
        Me.Controls.Add(Me.picBox37)
        Me.Controls.Add(Me.picBox36)
        Me.Controls.Add(Me.picBox35)
        Me.Controls.Add(Me.picBox34)
        Me.Controls.Add(Me.picBox33)
        Me.Controls.Add(Me.picBox32)
        Me.Controls.Add(Me.picBox31)
        Me.Controls.Add(Me.picBox28)
        Me.Controls.Add(Me.picBox27)
        Me.Controls.Add(Me.picBox26)
        Me.Controls.Add(Me.picBox25)
        Me.Controls.Add(Me.picBox24)
        Me.Controls.Add(Me.picBox23)
        Me.Controls.Add(Me.picBox22)
        Me.Controls.Add(Me.picBox21)
        Me.Controls.Add(Me.picBox18)
        Me.Controls.Add(Me.picBox17)
        Me.Controls.Add(Me.picBox16)
        Me.Controls.Add(Me.picBox15)
        Me.Controls.Add(Me.picBox14)
        Me.Controls.Add(Me.picBox13)
        Me.Controls.Add(Me.picBox12)
        Me.Controls.Add(Me.picBox11)
        Me.Controls.Add(Me.btnWin)
        Me.Controls.Add(Me.lblMatchStats)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.BtnHighScores)
        Me.Controls.Add(Me.lstGameStats)
        Me.HelpButton = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(816, 464)
        Me.MinimumSize = New System.Drawing.Size(816, 464)
        Me.Name = "frmGame"
        Me.Text = "Checkers"
        CType(Me.picBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox81, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstGameStats As ListBox
    Friend WithEvents BtnHighScores As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents lblMatchStats As Label
    Friend WithEvents btnWin As Button
    Friend WithEvents picBox11 As PictureBox
    Friend WithEvents picBox12 As PictureBox
    Friend WithEvents picBox13 As PictureBox
    Friend WithEvents picBox14 As PictureBox
    Friend WithEvents picBox15 As PictureBox
    Friend WithEvents picBox16 As PictureBox
    Friend WithEvents picBox17 As PictureBox
    Friend WithEvents picBox18 As PictureBox
    Friend WithEvents picBox28 As PictureBox
    Friend WithEvents picBox27 As PictureBox
    Friend WithEvents picBox26 As PictureBox
    Friend WithEvents picBox25 As PictureBox
    Friend WithEvents picBox24 As PictureBox
    Friend WithEvents picBox23 As PictureBox
    Friend WithEvents picBox22 As PictureBox
    Friend WithEvents picBox21 As PictureBox
    Friend WithEvents picBox48 As PictureBox
    Friend WithEvents picBox47 As PictureBox
    Friend WithEvents picBox46 As PictureBox
    Friend WithEvents picBox45 As PictureBox
    Friend WithEvents picBox44 As PictureBox
    Friend WithEvents picBox43 As PictureBox
    Friend WithEvents picBox42 As PictureBox
    Friend WithEvents picBox41 As PictureBox
    Friend WithEvents picBox38 As PictureBox
    Friend WithEvents picBox37 As PictureBox
    Friend WithEvents picBox36 As PictureBox
    Friend WithEvents picBox35 As PictureBox
    Friend WithEvents picBox34 As PictureBox
    Friend WithEvents picBox33 As PictureBox
    Friend WithEvents picBox32 As PictureBox
    Friend WithEvents picBox31 As PictureBox
    Friend WithEvents picBox88 As PictureBox
    Friend WithEvents picBox87 As PictureBox
    Friend WithEvents picBox86 As PictureBox
    Friend WithEvents picBox85 As PictureBox
    Friend WithEvents picBox84 As PictureBox
    Friend WithEvents picBox83 As PictureBox
    Friend WithEvents picBox82 As PictureBox
    Friend WithEvents picBox81 As PictureBox
    Friend WithEvents picBox78 As PictureBox
    Friend WithEvents picBox77 As PictureBox
    Friend WithEvents picBox76 As PictureBox
    Friend WithEvents picBox75 As PictureBox
    Friend WithEvents picBox74 As PictureBox
    Friend WithEvents picBox73 As PictureBox
    Friend WithEvents picBox72 As PictureBox
    Friend WithEvents picBox71 As PictureBox
    Friend WithEvents picBox68 As PictureBox
    Friend WithEvents picBox67 As PictureBox
    Friend WithEvents picBox66 As PictureBox
    Friend WithEvents picBox65 As PictureBox
    Friend WithEvents picBox64 As PictureBox
    Friend WithEvents picBox63 As PictureBox
    Friend WithEvents picBox62 As PictureBox
    Friend WithEvents picBox61 As PictureBox
    Friend WithEvents picBox58 As PictureBox
    Friend WithEvents picBox57 As PictureBox
    Friend WithEvents picBox56 As PictureBox
    Friend WithEvents picBox55 As PictureBox
    Friend WithEvents picBox54 As PictureBox
    Friend WithEvents picBox53 As PictureBox
    Friend WithEvents picBox52 As PictureBox
    Friend WithEvents picBox51 As PictureBox
    Friend WithEvents btnHelp As Button
End Class
